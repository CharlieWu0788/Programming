import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class CompilationEngine
{
    private final JackTokenizer tokenizer;
    private final BufferedWriter writer;
    private int indentLevel = 0;

    public CompilationEngine(JackTokenizer tokenizer, String outputPath) throws IOException
    {
        this.tokenizer = tokenizer;
        this.writer = new BufferedWriter(new FileWriter(outputPath));
    }

    public void close() throws IOException
    {
        writer.close();
    }

    public void compileClass() throws IOException
    {
        openTag("class");

        eat("class");

        writeCurrentToken();
        tokenizer.advance();

        eat("{");

        eat("}");

        closeTag("class");
    }

    private void writeLine(String line) throws IOException
    {
        for (int i = 0; i < indentLevel; i++)
        {
            writer.write("  ");
        }
        writer.write(line);
        writer.newLine();
    }

    private void openTag(String tag) throws IOException
    {
        writeLine("<" + tag + ">");
        indentLevel++;
    }

    private void closeTag(String tag) throws IOException
    {
        indentLevel--;
        writeLine("</" + tag + ">");
    }

    private String escapeXml(String s)
    {
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    private void writeCurrentToken() throws IOException
    {
        TokenType type = tokenizer.tokenType();
        String token = tokenizer.getCurrentToken();

        if (type == TokenType.KEYWORD)
        {
            writeLine("<keyword> " + token + " </keyword>");
        }
        else if (type == TokenType.SYMBOL)
        {
            writeLine("<symbol> " + escapeXml(token) + " </symbol>");
        }
        else if (type == TokenType.IDENTIFIER)
        {
            writeLine("<identifier> " + token + " </identifier>");
        }
        else if (type == TokenType.INT_CONST)
        {
            writeLine("<integerConstant> " + token + " </integerConstant>");
        }
        else if (type == TokenType.STRING_CONST)
        {
            writeLine("<stringConstant> " + tokenizer.stringVal() + " </stringConstant>");
        }
    }

    private void eat(String expected) throws IOException
    {
        if (!expected.equals(tokenizer.getCurrentToken()))
        {
            throw new RuntimeException();
        }
        writeCurrentToken();
        tokenizer.advance();
    }
}